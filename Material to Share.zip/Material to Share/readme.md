# Readme
This is the replication package for the paper _On the Effects of Program Slicing for Vulnerability Detection during Code Inspection_, it contains the raw data of the participant's responses, the reviewers may check the results. The tool used to create the slices is available on GitHub at this link: https://github.com/standash/foss-vuln-tracker/tree/master/repoman. 

- **Data** contains the google colab file created for the data analysis reported in the paper, and the two excel files containing the participants' answers needed to run the script. 
- **Experiment Material** contains the original files and sliced files provided to the students during the experiment
- **Training Material** contains the slide used for the training part of the experiment